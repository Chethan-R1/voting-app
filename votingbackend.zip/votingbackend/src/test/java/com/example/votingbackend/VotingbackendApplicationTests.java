package com.example.votingbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VotingbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
