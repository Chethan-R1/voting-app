package com.example.votingbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VotingbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(VotingbackendApplication.class, args);
	}

}
